#include<iostream>
using namespace std;
class MenuItem{
	
	private:
		string name;
		double price;
		string type;
		
	public:
		string getName(){
			return name;
		}
		void setName(string nm){
			name = nm;
		}
		
		double getPrice(){
			return price;
		}
		void setPrice(double pr){
			price = pr;
		}
		
		string getType(){
			return type;
		}
		void setType(string tp){
			type = tp;
		}
		
		~MenuItem(){
			cout<<"MenuItemobject Distructor"<<endl;
		}
		
		MenuItem(){
			name = " ";
			price = 0.0;
			type = " ";
		}
		
		MenuItem(string a, double b, string c){
			name = a;
			price = b;
			type = c;	
		}
		
		
		void display(){
			cout<<endl;
			cout<<"Item Data is :"<<endl;
			cout<<"Name  : "<<name<<endl<<"Price : "<<price<<endl<<"Type : "<<type<<endl;
			cout<<endl;
		}
};

class Resturant{
	private:
		string name;
		string address;
		MenuItem M1;
		
	public:
		
		string getName(){
			return name;
		}
		void setName(string nme){
			name = nme;
		}
		string getAddress(){
			return address;
		}
		void setAddress(string add){
			address = add;
		}
		
		Resturant(){
		name = " ";
		address = " ";
		M1.setName(" ");
		M1.setPrice(0.0);
		M1.setType(" ");
	}
		
		Resturant(string d, string e,  string f, double g,string h){
			name = d;
			address = e;
			M1.setName(f);
			M1.setPrice(g);
			M1.setType(h);
		}
		
		void displayItems(){
			string i ; string j;
	        double k;
	        cout << "Enter The Item Name : " ;
	        cin >>i;
	        M1.setName(i);
	        
	        cout << "Enter The Item Type : ";
	        cin>>j;
	        M1.setType(j);
	        
	        cout << "Enter The Item Price : ";
	        cin >>k;
	        M1.setPrice(k);
			M1.display();
	             
	}	
};

int main()
{
	Resturant R1 , R2;
	string s ; string t;
	cout<<"Enter The Resturant Name : ";
	cin>>s;
	R1.setName(s);
	cout<<"Enter The Resturant Address : ";
	cin>>t;
	R1.setAddress(t);
	R1.displayItems();
	
	string u ; string v;
	cout<<"Enter The Resturant Name : " ;
	cin>>u;
	R2.setName(u);
	cout<<"Enter The Resturant Address : ";
	cin>>v;
	R2.setAddress(v);
	R2.displayItems();
	
    return 0;	

}
