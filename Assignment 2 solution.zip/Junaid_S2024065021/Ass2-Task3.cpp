#include<iostream>
using namespace std;
class Product{
	private:
    	string name;
	    double price;
	    int quantity;
	
	public:
		string getName(){
			return name;
		}
		
		void setname(string nm){
			name = nm;
		}
		
		double getPrice(){
			return price;
		}
		
		void setPrice(double pr){
			price = pr;
		}
		
		int getQuantity(){
			return quantity;
		}
		
		void setQuantity(int qn){
			quantity = qn;
		}
		
		~Product(){
			cout<<"Productobject Distructor"<<endl;
		}
		
		Product(){
			name = " ";
			price = 0.0; 
			quantity = 0;
		}
		
		Product(string a ,double b, int c){
			name = a ;
			price = b ;
			quantity = c ;
		}
		
		void display(){
			cout<<endl;
			cout<<"Your Order is :"<<endl;
			cout<<"Name :"<<name<<endl<<"Price :"<<price<<endl<<"Quantity :"<<quantity<<endl;
			cout<<endl;
		}
};

class Order{
	private:
		string orderID;
		Product p1;
		
	public:
		string getOrderID(){
			return orderID;
		}
		
		void setOrderID(string od){
			orderID = od;
		}
		
		Order(string o, string p , double q, int r){
			orderID = o ;
			p1.setname(p) ;
			p1.setPrice(q) ;
			p1.setQuantity(r) ;
		}
		
		Order(){
		 orderID = " ";
		 p1.setname(" ");
		 p1.setPrice(0.0);
		 p1.setQuantity(0);	
		}
		
		void displayProduct(){
			string p;
			double q;
			int r;
			
			cout<<"Enter the name : ";
			cin>>p;
			p1.setname(p);
			
			cout<<"Enter the price : ";
			cin>>q;
			p1.setPrice(q);
			
			cout<<"Enter the quantity : ";
			cin>>r;
			p1.setQuantity(r);
			
			cout<<"Totalcost is : "<<q*r<<endl;
			p1.display();
		}	
};

int main()
{
	Order O1 , O2;
	string m;
	cout<<"Enter First OrderID : ";
	cin>>m;
	O1.setOrderID(m);
	O1.displayProduct();
	
	string n;
	cout<<"Enter 2nd OrderID : ";
	cin>>n;
	O1.setOrderID(n);
	O1.displayProduct();
	
	return 0;
}
