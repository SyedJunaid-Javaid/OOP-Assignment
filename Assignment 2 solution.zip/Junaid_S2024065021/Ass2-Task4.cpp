#include<iostream>
using namespace std;
class Customer{
	private:
	int uniqueId;
	string name , email;
	static int totalCustomers;
	
	public:
		int getUniqueId(){
			return uniqueId;
		}
		void setUniqueId(int ui){
	    	uniqueId = ui;
		}
		string getName(){
			return name;
		}
		void setName(string nm){
			name = nm;
		}
		string getEmail(){
			return email;
		}
		void setEmail(string em){
			email = em;
		}
		
		~Customer(){
		    cout<<"Customer Distructor"<<endl;
		}
	    
		Customer(){
			uniqueId = 0;
			name = " ";
			email =  " ";
			totalCustomers++;
		}

		Customer(int a, string b, string c){
			uniqueId = a ;
			name = b ;
			email = c ;
			totalCustomers++;
		}
		void display ()
		{
			cout<<endl;
			cout<<"The Customer Registration is : "<<endl;
			cout<<"ID of Customer : "<<uniqueId<<endl<<"Name : "<<name<<endl<<"Email : "<<email<<endl;
			cout<<endl;
		}

		static int getTotalCustomers()
		{
			return totalCustomers;
		}
};
     int Customer::totalCustomers = 0;
int main ()
{
	 Customer C1, C2;
	 	    int h;
			string i ; string j ;
			cout<<"Enter ID of Customer : " ;
			cin>>h;
			cout<<"Enter name : " ;
			cin>>i;
			cout<<"Enter Email : ";
			cin>>j;
			C1.setUniqueId(h);
			C1.setName(i);
			C1.setEmail(j);
			C1.display();
			

	 	    int d;
			string e ; string f;
			cout<< "Enter ID of Customer : " ;
			cin>>d;
			cout<< "Enter name : " ;
			cin>>e;
			cout<< "Enter Email : ";
			cin>>f;
			C2.setUniqueId(d);
			C2.setName(e);
			C2.setEmail(f);
			C2.display();
			
			cout<<"The Total Number of Customers are: "<<Customer::getTotalCustomers()<<endl;
		
			return 0;
}
