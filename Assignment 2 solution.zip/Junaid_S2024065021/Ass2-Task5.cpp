#include<iostream>
using namespace std;
class Book{
	private:
		string bookTitle , authorName , isbnNumber;
		static int totalBooks;
		
	public:
	    string getBookTitle(){
	    	return bookTitle;
		}
		
		void setBookTitle(string bt){
			bookTitle = bt;
		}
		
		string getAuthorName(){
			return authorName;
		}
		
		void setAuthorName(string an){
			authorName = an;
		}
		
		string getIsbnNumber(){
			return isbnNumber;
		}
		
		void setIsbnNumber(string in){
			isbnNumber = in;
		}
		
		~Book(){
			cout << "BookObject Destructor"<<endl;
		}

		Book(){
			bookTitle=" ";
			authorName= " ";
			isbnNumber=" ";
			totalBooks++;
		}

		Book(string a, string b, string c){
			bookTitle = a;
			authorName = b;
			isbnNumber = c;
			totalBooks++;
		}
		void displayBook(){
			cout<<"Book Title : "<<bookTitle<<endl<<"Author Name : "<<authorName <<endl<<"ISBN Number : "<<isbnNumber << endl;
		}

		static int getTotalBooks(){
			return totalBooks;
		}
};
   int Book::totalBooks = 0;
int main()
{
   Book B1("Alif Baa Introduction to Arabic Letters and Sounds", "Kristen Brustad, Mahmoud Al-Batal, Abbas Al-Tonsi" , "9781589016323" );
   cout <<"Book1 : " <<endl;
   B1.displayBook();
   cout<<endl;
   Book B2("Blue's Hanging","Yamanaka","9780380731398");
   cout <<"Book2 : " <<endl;
   B2.displayBook();
   cout<<endl;
   Book B3("Environmental and Natural Resource Economics","Harris & Roach","9780765637925");
   cout <<"Book3 : " <<endl;
   B3.displayBook();
   cout<<endl;
   cout<<"All books in the library are : "<<Book::getTotalBooks()<<endl;

   return 0; 
}
