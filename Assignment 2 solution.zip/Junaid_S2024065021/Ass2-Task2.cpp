#include<iostream>
using namespace std;
class Student{
	private:
		string name;
		int rollNumber;
		string program;
		
	public:
	string getName(){
		return name;
	}
	
	void setName(string nm){
		name = nm;
	}
	
	int getRollNumber(){
		return rollNumber;
	}
	
	void setRollNumber(int rn){
		rollNumber = rn;
	}
	
	string Program(){
		return program;
	}
	
	void setProgram(string pg){
		program = pg;
	}

    ~Student(){
		cout<<"Studentobject Distructor" <<endl;
	}
	 
	Student(){
		name = 0.0;
		rollNumber = 0;
		program = 0.0;
	}

	Student(string a, int b, string c){
		name = a;
		rollNumber = b;
		program = c;
	}
	void display()
	{
		cout<<endl;
		cout<<"Students has Added in this Department :"<<endl;
		cout<<"Name : "<<name<<endl<<"RollNumber : "<<rollNumber<<endl<<"Program : "<<program<<endl;
		cout<<endl;
	}
};

class Department{
	private:
		string name ; string code;
		Student S1;
		
	public:
	
		string getName(){
			return name;
		}
		void setName(string x){
			name = x;
		}
		
		string getCode(){
			return code;
		}
		void setCode(string y){
			code = y;
		}

		 Department(){
		 	name = " ";
		 	code = " "; 
		    S1.setName(" ")	;
		    S1.setRollNumber(0);
		    S1.setProgram(" ");
		 }
	
		 Department(string d, string e,string f, int g, string h){
		 	name=d;
		 	code=e;
		 	S1.setName(f)	;
		    S1.setRollNumber(g);
		    S1.setProgram(h);
		 }

		 void displayStudent(){
		 	string i;
		 	int j;
		 	string k;
		 	
		 	cout<<"Enter student Name : ";
		 	cin>>i;
		 	S1.setName(i);
		 	
		 	cout<<"Enter student RollNumber : ";
		 	cin>>j;
		 	S1.setRollNumber(j);
		 	
		 	cout<<"Enter student Program : ";
		 	cin>>k;
		 	S1.setProgram(k);
		 	
		 	S1.display();
		 }
};

int main()
{
	Department D5;
	string l; string m;
    cout<<"Enter Department Name : ";
    cin>>l;
    D5.setName(l);
    
    cout<<"Enter Department Code : ";
    cin>>m;
    D5.setCode(m);
    D5.displayStudent();
    
    Department D6;
    string n ; string o;
    cout<<"Enter Department Name : ";
    cin>>n;
    D6.setName(n);
    
    cout<<"Enter Department Code : ";
    cin>>o;
    D6.setCode(o);
    D6.displayStudent();
    
     return 0;
}
