#include<iostream>
using namespace std;
class ComplexNumber{
	private:
		float real;
		float imag;
	public:
		ComplexNumber(){
			real=0;
			imag=0;
		}
		ComplexNumber(float r, float i ){
			real = r;
			imag = i;
		}
		float getReal(){
			return real;
		}
		void setReal(float a){
			real = a;
		}
		float getImag(){
			return imag;
		}
		void setImag(float b){
			imag = b;
		}
		~ComplexNumber(){
			cout<<"ComplexNumber object Distructor"<<endl;
		}
	
		void display(){
			cout<<real<<"+"<<imag<<"i"<<endl;
		}
		ComplexNumber operator+(ComplexNumber obj){
			ComplexNumber CN;
			CN.real = real+obj.real;
			CN.imag = imag+obj.imag;
			return CN;
		}
		ComplexNumber operator-(ComplexNumber obj){
			ComplexNumber CN;
			CN.real = real-obj.real;
			CN.imag = imag-obj.imag;
			return CN;	
		}
		ComplexNumber operator*(ComplexNumber obj){
			ComplexNumber CN;
			CN.real = real*obj.real-imag*obj.imag;
			CN.imag = real*obj.imag+imag*obj.real;
			return CN;
		}
		bool operator<(ComplexNumber obj){
			if(real<obj.real&&imag<obj.imag){
			return true;
			}
			else{return false;}
		}
		bool operator>(ComplexNumber obj){
			if(real>obj.real&&imag>obj.imag){
				return true;
			}
			else{
				return false;
			}
		}
		bool operator==(ComplexNumber obj){
			if(real==obj.real&&imag==obj.imag){
				return true;
			}
			else{
				return false;
			}
		}
			
			bool operator>=(ComplexNumber obj)
		{
			if(real>=obj.real&&imag>=obj.imag){
			 return	true;
			}
			else{
				return false;
			}
		}
			bool operator<=(ComplexNumber obj){
			if(real<=obj.real&&imag<=obj.imag){
				return true;
			}
			else{
				return false;
			}
		}
			bool operator!=(ComplexNumber obj){
			if(real!=obj.real&&imag!=obj.imag){
			 return true;
			}
			else{
			  return false;
			}
		}
		void operator++(){
			real = real+1;
		}
		void operator++(int r){
			real = real+1;
		}
		void operator--(){
			real = real-1;
		}
		void operator--(int s){
			real = real-1;
	}
};

int main(){
	ComplexNumber C1(1,2);
	cout<<"Enter first ComplexNumber"<<endl;
	C1.display();
	ComplexNumber C2(3,4);
	cout<<"Enter second ComplexNumber"<<endl;
	C2.display();
	
	ComplexNumber C3;
	C3 = C1+C2;
	cout<<"Addition Operator + : "<<endl;
	C3.display();
	
	ComplexNumber C4;
	C4 = C1-C2;
	cout<<"Subtract Operator - : "<<endl;
	C4.display();
	
	ComplexNumber C5;
	C5 = C1*C2;
	cout<<"Multiplication Operator * : "<<endl;
	C5.display();
	
	cout<<"Comparison (C1 > C2): "<<(C1>C2)<<endl;
    cout<<"Comparison (C1 < C2): "<<(C1<C2)<<endl;
    cout<<"Comparison (C1 == C2): "<<(C1==C2)<<endl;
	
	C2++;
	cout<<"Post Increment is ++: "<<endl;
	C2.display();
	
	++C1;
	cout<<"++ Pre Increment is : "<<endl;
	C1.display();
	
	C2--;
	cout<<"Post Decrement is -- : "<<endl;
	C2.display();
	
	--C1;
	cout<<"-- Pre Decrement is : "<<endl;
	C1.display();	
	
	return 0;
}












