#include<iostream>
using namespace std;
class Fraction{
	private:
		int num;
		int den;
	public:
		
		Fraction(){
			num = 0;
			den = 1;
		}
		Fraction(int n, int d){
			num = n;
			den = d;
			if(d == 0){
				cout<<"Denominator will not be zero"<<endl;
			}
			else{
				cout<<" "<<endl;
			}
		}
		int getNum(){
			return num;
		}
		void setNum(int a){
			num = a;
		}
		int getDen(){
			return den;
		}
		void setDen(int b){
			den = b;
		}
		~Fraction(){
			cout<<"Fraction Object Destructor"<<endl;
		}
	
		void display(){
			cout<<"The Fraction is : "<<num<<"/"<<den<<endl;
			cout<<endl;
		}
		Fraction operator+(Fraction obj){
			Fraction temp;
			temp.num = num*obj.den+obj.num*den;
			temp.den = den*obj.den;
			return temp;			
		}
			Fraction operator-(Fraction obj){
			Fraction temp;
			temp.num = num*obj.den-obj.num*den;
			temp.den = den*obj.den;
			return temp;			
		}
			Fraction operator*(Fraction obj){
			Fraction temp;
			temp.num = num*obj.num;
			temp.den = den*obj.den;
			return temp;			
		}
		    Fraction operator/(Fraction obj){
		    Fraction temp;
			temp.num = num*obj.den;
			temp.den = den*obj.num;
			return temp;	
		}
		
		void operator++(){
        	num=num+den;
			den=den;	
		}	
		void operator++(int x){
			num=num+den;
			den=den;
		}
		void operator--(){
			num=num-den;
			den=den;
		
		}
		void operator--(int y){
			num=num-den;
			den=den;
		}
				
};
int main(){
	Fraction F1(4,6);
	cout<<"1st Fraction "<<endl;
	F1.display();
	Fraction F2(8,10);
	cout<<"2nd Fraction "<<endl;
	F2.display();
	
	Fraction F3;
	F3=F1+F2;
	cout<<"Addind operator + : "<<endl;
	F3.display();
	
	Fraction F4;
	F4=F1-F2;
	cout<<"Subtraction operator - : "<<endl;
	F4.display();
	
	Fraction F5;
	F5=F1*F2;
	cout<<"Multiplication operator * : "<<endl;
	F5.display();
	
	Fraction F6;
	F6=F1/F2;
	cout<<"Division operator / : "<<endl;
	F6.display(); 
	
	F1++;
	F2++;
	cout<<"Post Increment ++ : "<<endl;
	F1.display();
	F2.display();
	
	++F1;
	++F2;
	cout<<"++ Pre Increment  : "<<endl;
	F1.display();
	F2.display();
	
	F1--;
	F2--;
	cout<<"Post Decrement is --  : "<<endl;
	F2.display();
	F3.display();
	
	--F1;
	--F2;
	cout<<"-- Pre Decrement is : "<<endl;
	F1.display();
	F2.display();
	
	return 0;
}
