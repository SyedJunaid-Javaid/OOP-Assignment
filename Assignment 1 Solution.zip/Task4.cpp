#include<iostream>
using namespace std;
class Rational
{
	private:
		int numerator;
		int denominator;
	public:
		int getX1(){
		    return numerator;
		}
		void setX1(int x1){
		    numerator = x1;
		}
		
		int getX2(){
		    return denominator;
		}
		void setX2(int x2){
			if(x2==0){
				denominator = 1;
			}
			else{
				denominator = x2;
			}
		}
		~Rational(){
		    cout<<"Rational Destructor"<<endl;
		}
		Rational(){
		    numerator = 0;
		    denominator = 0;
		}
		Rational(int a, int b){
		    numerator = a;
            denominator = b;
        }
        void display(){
        cout<<"Fraction : "<<numerator<<"/"<<denominator<<endl;
		}
	};

int main(){
	Rational r1;
	int y , z;
	cout<<"Enter value of numerator: ";
	cin>>y;
	r1.setX1(y);
    r1.getX1();
    
	cout<<"Enter value of denominator: ";
	cin>>z;
    r1.setX2(z);
    r1.getX2();

    r1.display();

return 0;
	}
