#include <iostream>
#include <cmath>
using namespace std;

class QuadraticEquation{
    private:
        int A, B, C;
        double discriminant;
        int q,w;
    public:
        int getNUM1(){
		    return A;
		}
		void setNUM1(int x){
		  A = x;
		}
		
		int getNUM2(){
			return B;
		}
		void setNUM2(int y){
			B = y;	
		}
		
        int getNUM3(){
		    return C;
		}
        void setNUM3(int z){ 
		    C = z;
		}
		 	
        QuadraticEquation(){
        	A = 0;
        	B = 0;
        	C = 0;
		}
		
		~QuadraticEquation(){
			cout<<"QuadraticEquation distroyed"<<endl;
		}
		
        QuadraticEquation(int a, int b, int c){
			A = a ;
			B = b ;
			C = c ;
        }
        void calquadraticformula(int A,int B,int C){
        discriminant=(B*B-4*A*C);
	        if(discriminant>=0){
                q=(-B- sqrt(discriminant))/2*A;
                w=(-B+ sqrt(discriminant))/2*A;

        cout<<"pos root "<<q<<endl<<"neg root "<<w<<endl;
	}else{
	    cout<<"ans is in the form of i"<<endl;
	}
        }
		
		};
        int main(){
            
        QuadraticEquation q1;
        int l,m,n;
        cout<<"Enter value of A ";
        cin>>l;
        cout<<"Enter value of B ";
        cin>>m;
        cout<<"Enter value of C: ";
        cin>>n;
        q1.calquadraticformula(l,m,n);
    
        QuadraticEquation q2;
        int i,o,p;
        cout<<"Enter value of A ";
        cin>>i;
        cout<<"Enter value of B ";
        cin>>o;
        cout<<"Enter value of C: ";
        cin>>p;
        q1.calquadraticformula(i,o,p);
    
    return 0;
        
        }
