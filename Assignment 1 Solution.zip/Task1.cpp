#include <iostream>
using namespace std;
class Time
{
	private:
		int hour,minute,second;
		
	public:
	int getHour(){
		return hour;
	}
	void setHour(int h){
		hour = h;
	}
	
	int getMinute(){
		return minute; }
	void setMinute(int m){
		minute = m;
	}
	
	int getSecond(){
		return second;
	}
	void setSecond(int s){
		second = s;
	}
	
	Time(){
		hour = 0;
		minute = 0;
		second = 0;
	}
	
	~Time(){
		cout<<"Time Destructor"<<endl;
	}
	Time(int a, int b, int c){
		hour = a;
		minute = b;
		second = c;
		cout<<"Time 2 : "<<hour<<":"<<minute<<":"<<second<<endl;
	}
	void display(){
		cout<<"Time 1 : "<<hour<<":"<<minute<<":"<<second<<endl;
	}
};
int main(){
	Time t1;
	int a; int b; int c;
	
	cout<<"Enter Hour : ";
	cin>>a;
	if(a>=0 && a<=24){
		t1.setHour(a);
	}
	else{
		cout<<"Invalid Hour"<<endl;
		return 1 ;
	}
	
	cout<<"Enter Minute : ";
	cin>>b;
	if(b>= 0 && b<=60){
		t1.setMinute(b);
	}
	else{
cout<<"Invalid Minute"<<endl;
		return 1 ;
	}
	
	cout<<"Enter Second :";
	cin>>c;
	if(c>=0 && c<=60){
	    t1.setSecond(c);
	}
	else{
cout<<"Invalid Second"<<endl;
		return 1 ;
	}
t1.display();

int x,y,z;

cout<<"Enter Hour : ";
cin>>x;
cout<<"Enter Minute : ";
cin>>y;
cout<<"Enter Second :";
cin>>z;
if(x>=0 && x<=24 && y>=0 && y<=60 && z>=0 && z<=60){
Time t2(x,y,z);
	}
	else{
cout<<"Invalid Minute"<<endl;
	}


	
	return 0;
}
