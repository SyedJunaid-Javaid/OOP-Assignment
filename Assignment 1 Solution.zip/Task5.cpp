#include<iostream>
using namespace std;
class Time{
	private:
		int hour; int minute; int second;
	public:
		
		int getHour(){
			return hour;
		}
		void setHour(int h){
			hour = h;
		}
		
		int getMinute(){
			return minute;
		}
		void setMinute(int m){
			minute = m;
		}
		
		int getSecond(){
			return second;
		}
		void setSecond(int s){
			second = s;
		}
		
		Time(){
			hour = 0;
			minute = 0;
			second = 0;
		}
		
		~Time(){
			cout<<"Time distructor"<<endl;
		}
		
		Time(int a,int b,int c){
			hour = a;
			minute = b;
			second = c;
		}
		
		void display() {
		for(int i=0; i<=4; i++){
    	if (hour>= 24) {
          hour = 0;
        }
        
        if (minute >= 60) {
        minute = 0;
        hour++;
		}
		
		if (second >= 60) {
      	second = 0;
      	minute++;
		}
		cout <<"The Time = "<<hour<<":"<<minute<<":"<<second;
		second++;
		
		if(hour==12 && hour<=12){
			cout<<" AM"<<endl;
		}
		else{
			cout<<" PM"<<endl;
		}
    }

}	
	};
	
	int main(){
		Time t1,t2,t3;
		cout<<"Incrementing into the next minute."<<endl;
		
		t1.setHour(3);
		t1.getHour();
		t1.setMinute(58);
		t1.getMinute();
		t1.setSecond(58);
		t1.getSecond();
		t1.display();
		
		cout<<endl;
		
		cout<<"Incrementing into the next hour."<<endl;
		t2.setHour(7);
		t2.getHour();
		t2.setMinute(59);
		t2.getMinute();
		t2.setSecond(58);
		t2.getSecond();
		t2.display();
		
		cout<<endl;
		
		cout<<"Incrementing into the next day (i.e., 11:59:59 PM to 12:00:00 AM)."<<endl;
		t3.setHour(11);
		t3.getHour();
		t3.setMinute(59);
		t3.getMinute();
		t3.setSecond(58);
		t3.getSecond();
		t3.display();
		
		cout<<endl;
		
		return 0;
	}
