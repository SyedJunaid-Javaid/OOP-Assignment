#include <iostream>
using namespace std;
class Car
{
	private:
		string carname, carnumber;
		int carmodel, carprice;
		
	public:
	string getCarname(){
		return carname;
	}
	void setCarname(string h){
	carname = h;
	}
	
	string getCarnumber(){
		return carnumber;
	}
	void setCarnumber(string i){
	carnumber = i;
	}
	
	int getCarprice(){
		return carprice;
	}
	void setCarprice(int j){
		carprice = j;
	}
	
	int getCarmodel(){
		return carmodel;
	}
	void setCarmodel(int k){
		carmodel = k;
	}
	
		Car(){
		carname = " ";
		carnumber = " ";
		carprice = 0;
		carmodel = 0;
	}
	
	~Car(){
		cout<<"Car Destructor"<<endl;
	}
	car(int a, int b, int c, int d){
		carname = a;
		carnumber = b;
		carprice = c;
		carmodel = d;
	}
	void display(){
		cout<<"Carname :"<<carname<<endl<<"Carmodel :"<<carmodel<<endl<<"Carnumber :"<<carnumber<<endl<<"CarPrice :"<<carprice<<endl;
	}
};
int main(){
	Car c1;
	int w; int x; string y; string z;
	c1.setCarname("Civic x");
	c1.setCarmodel(2018);
	c1.setCarnumber("AXC-9187");
	c1.setCarprice(5550000);
	c1.display();

	return 0;
}
