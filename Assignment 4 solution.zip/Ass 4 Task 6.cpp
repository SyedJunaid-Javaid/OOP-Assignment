#include<iostream>
using namespace std;
class BasicShape{
	private:
		double area;
	public:
		//getter
		double getArea() const
		{
			return area;
		}
		//setter
		void setArea(double a)
		{
			area=a;
		}
		//Default Constructor
		BasicShape()
		{
			area=0.0;
		}
		//Parameterized Constructor
		BasicShape(double a)
		{
			area=a;
		}
		//Destructor
		~BasicShape()
		{
			cout << "BasicShape Object Destroyed" << endl;
		}
		//Display
		virtual void display() const
		{
			cout << "BasicShape Calculate Area Function...." << endl;
		}
		//Calculate Area
		virtual double calcArea() const
		{
			0;
		}
};
class Circle : public BasicShape
{
	private:
		long centerX;
		long centerY;
		double radius;
	public:
		//getters
		long getCenterX() const
		{
			return centerX;
		}
		long getCenterY() const
		{
			return centerY;
		}
		double getRadius() const
		{
			return radius;
		}
		//setters
		void setCenterX(long c)
		{
			centerX=c;
		}
		void setCenterY(long e)
		{
			centerY=e;
		}
		void setRadius(double r)
		{
			radius=r;
		}
		//Default Constructor
		Circle()
		{
			centerX=0;
			centerY=0;
			radius=0.0;
		}
		//Parameterized Constructor
		Circle(long a, long b , double c ): BasicShape()
		{
			centerX=a;
			centerY=b;
			radius=c;
		}
		//Destructor
		~Circle()
		{
			cout << "Circle Object Destroyed" << endl;
		}
		//Display
		void display() const
		{
			BasicShape::display();
			cout << "Center X : " << centerX << endl;
			cout << "Center Y : " << centerY << endl; 
			cout << "Radius : " << radius << endl;
		}
		//Calculate Area
		 double calcArea() const
		 {	
		 	double area = 3.14 * radius * radius;
		 	cout << "Area of Circle : " << area << endl;
		 	return area;
		 }
};
class Rectangle : public BasicShape
{
	private:
		long width;
		long length;
	public:
		//getter
		long getWidth() const
		{
			return width;
		}
		long getLength() const
		{
			return length;
		}
		//setters
		void setWidth(long w)
		{
			width=w;
		}
		void setLength(long l)
		{
			length=l;
		}
		//Default Constructor
		Rectangle()
		{
			length=0;
			width=0;
		}
		//Parameterized Constructor
		Rectangle(long w , long l ):BasicShape()
		{
			width=w;
			length=l;
		}
		//Destructor
		~Rectangle()
		{
			cout << "Rectangle Object Destroyed" << endl;
		}
		//Display
		void display() const
		{
			BasicShape::display();
			cout << "Length of Rectangle : " << length << endl;
			cout << "Width of Rectangle : " << width << endl;
		}
		//Calculate Area
		double calcArea() const
		{
		
			double area=length * width;
			cout << "Area of Rectangle : " << area << endl;
			return area;
		}
};
int main()
{
	BasicShape*ptr;
	Circle C1( 5 , 10 , 7.5);
	ptr = &C1;
	ptr->display();
	ptr->calcArea();
	
	BasicShape*ptr1;
	Rectangle R(34 , 32);
	ptr1 = &R;
	ptr1->display();
	ptr1->calcArea();
	
	return 0;
}
