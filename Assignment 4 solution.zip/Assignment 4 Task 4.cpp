#include <iostream>
#include <string>
using namespace std;
class Person
{
  protected:
     string name;
	 float id;
  public:
    Person(string n,float i)
	{
		name=n;
		id=i;
	}
	~Person()
	{
		cout<<"Person Destructor."<<endl;
	}
	string getName()const
	{
		return name;
	}
	float getId()const
	{
		return id;
	}
	void setName(string a)
	{
		name=a;
	}
	void setId(float b)
	{
		id=b;
	}
	virtual void display()const
	{
		cout<<"Name:"<<name<<endl;
		cout<<"Id:"<<id<<endl;
	}	
};
class Student:public Person
{
	private:
		char grade;
		int marks;
	public:
		Student(char g,int m,string x,float y):Person(x,y)
		{
			grade=g;
			marks=m;
		}
	~Student()
	{
		cout<<"Student Destructor."<<endl;
	}
	char getGrade()const
	{
		return grade;
	}
	int getMarks()const
	{
		return marks;
	}
	void setGrade(char u)
	{
		grade=u;
	}
	void setMarks(int v)
	{
		marks=v;
	}
	void display()const
	{
		cout<<"Grades:"<<grade<<endl;
		cout<<"Marks:"<<marks<<endl;
		Person::display();
	}
};
class Teacher:public Person
{
   private:
     float salary;
	 float tax;
   public:
     Teacher(float s,float t,string f,float e):Person(f,e)
	{
	 	salary=s;
	 	tax=t;
	}
	~Teacher()
	{
		cout<<"Teacher Destructor."<<endl;
	}
	float getSalary()const
	{
		return salary;
	}
	float getTax()const
	{
		return tax;
	}
	void setSalary(float x)
	{
		salary=x;
	}
	void setTax(float y)
	{
		tax=y;
	}
	void display()const
	{
		cout<<"Salary:"<<salary<<endl;
		cout<<"Tax:"<<tax<<endl;
		Person::display();
	}
};
int main()
{
	Person*ptr;
	Student s('A',29,"Alisha",056);
	ptr=&s;
	ptr->display();
	
	Teacher t(65000,3500,"Iram",0034);
	ptr=&t;
	ptr->display();
	
	return 0;
}
