#include <iostream>
#include <string>
using namespace std;
class Publication
{
	protected:
		string title;
		float price;
	public:
		Publication(string t,float p)
		{
           	title=t;
           	price=p;
		}
		~Publication()
		{
			cout<<"Publication Destructor."<<endl;
		}
		string getTitle()const
		{
			return title;
		}
		float getPrice()const
		{
			return price;
		}
		void setTitle(string a)
		{
			title=a;
		}
		void setPrice(float p)
		{
			price=p;
		}
		virtual void display()const
		{
			cout<<"Title:"<<title<<endl;
			cout<<"Price:"<<price<<endl;
		}
};
class Book:public Publication
{
	private:
		int count;
	public:
		Book(int x,string y,float z):Publication(y,z)
		{
			count=x;
		}
		~Book()
		{
			cout<<"Book Destructor."<<endl;
		}
        int getCount()const
		{
			return count;
		}		
		void setCount(int c)
		{
			count=c;
		}
		void display()const
		{
		    cout<<"Count:"<<count<<endl;
			Publication::display();	
		}		
};
class AudioCassettes:public Publication
{
    private:
	    float playingTime;
	public:
	    AudioCassettes(float h,string i,float j):Publication(i,j)
	    {
	    	playingTime=h;
		}
		~AudioCassettes()
		{
			cout<<"Audio Cassettes Destructor."<<endl;
		}
		float getPlayingTime()const
		{
			return playingTime;
		}
		void setPlayingTime(float t)
		{
			playingTime=t;
		}
		void display()const
		{
			cout<<"Playing Time:"<<playingTime<<"sec"<<endl;
			Publication::display();
		}
};
int main()
{
	Publication*ptr;
	Book b(7,"My Fault",680);
	ptr=&b;
	ptr->display();
	
	AudioCassettes a(230,"Your Fault",990);
	ptr=&a;
	ptr->display();
	
	return 0;
}
