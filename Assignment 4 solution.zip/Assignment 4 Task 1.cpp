#include <iostream>
#include <string>
using namespace std;
class Book
{
	protected:
	  string name;
	public:
		Book(string n)
		{
		  name=n;
		}
	    ~Book()
	    {
	    	cout<<"Book Destructor."<<endl;
		}
		string getName()const
		{
			return name;
		}
		void setName(string a)
		{
			name=a;
		}
		virtual void display()const
		{
			cout<<"Name:"<<name<<endl;
		}
};
class ComputerScience:public Book
{
	private:
		string authorName;
	public:
	ComputerScience(string y,string z):Book(y)
	{
		authorName=z;
	}
	~ComputerScience()
	{
		cout<<"Computer Science Destructor."<<endl;
	}
	string getAuthorName()const
	{
		return authorName;
	}
	void setAuthorName(string x)
	{
		authorName=x;
	}
	void display()const
	{
		cout<<"Author Name:"<<authorName<<endl;
		Book::display();
	}
};
int main()
{
	Book*ptr;
	ComputerScience s1("It Starts With Us","Collen Hoover");
	ptr=&s1;
	ptr->display();
	
	return 0;
}
