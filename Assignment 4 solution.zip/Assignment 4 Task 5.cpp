#include <iostream>
#include <string>
using namespace std;
class Person
{
  protected:
     string name;
	 float id;
  public:
    Person(string n,float i)
	{
		name=n;
		id=i;
	}
	~Person()
	{
		cout<<"Person Destructor."<<endl;
	}
	string getName()const
	{
		return name;
	}
	float getId()const
	{
		return id;
	}
	void setName(string a)
	{
		name=a;
	}
	void setId(float b)
	{
		id=b;
	}
	virtual void display()const
	{
		cout<<"Name:"<<name<<endl;
		cout<<"Id:"<<id<<endl;
		cout<<"              "<<endl;
	}	
};
class Student:public Person
{
	private:
		char grade;
		int marks;
	public:
		Student(char g,int m,string x,float y):Person(x,y)
		{
			grade=g;
			marks=m;
		}
	~Student()
	{
		cout<<"Student Destructor."<<endl;
	}
	char getGrade()const
	{
		return grade;
	}
	int getMarks()const
	{
		return marks;
	}
	void setGrade(char u)
	{
		grade=u;
	}
	void setMarks(int v)
	{
		marks=v;
	}
	void display()const
	{
		cout<<"Grades:"<<grade<<endl;
		cout<<"Marks:"<<marks<<endl;
		Person::display();
	}
};
class Teacher:public Person
{
   private:
     float salary;
	 float tax;
   public:
     Teacher(float s,float t,string f,float e):Person(f,e)
	{
	 	salary=s;
	 	tax=t;
	}
	~Teacher()
	{
		cout<<"Teacher Destructor."<<endl;
	}
	float getSalary()const
	{
		return salary;
	}
	float getTax()const
	{
		return tax;
	}
	void setSalary(float x)
	{
		salary=x;
	}
	void setTax(float y)
	{
		tax=y;
	}
	void display()const
	{
		cout<<"Salary:"<<salary<<endl;
		cout<<"Tax:"<<tax<<endl;
		Person::display();
	}
};
class BS_student:public Student
{
	private:
		string project;
	public:
		BS_student(string p,string n,float i,char g,int m):Student(g,m,n,i)
		{
          project=p;			
		}
	~BS_student()
	{
		cout<<"BS Student Destructor."<<endl;
	}
	string getProject()const
	{
		return project;
	}
	void setProject(string a)
	{
		project=a;
	}
	void display()const
	{
		cout<<"Project:"<<project<<endl;
		Student::display();
	}
};
class MS_student:public Student
{
    private:
	  string surveySummary;
	public:
		MS_student(string s,string a,float b,char c,int d):Student(c,d,a,b)
		{
			surveySummary=s;
		}
	~MS_student()
	{
		cout<<"MS Student Destructor."<<endl;
	}
	string getSurveySummary()const
	{
		return surveySummary;
	}
	void setSurveySummary(string x)
	{
		surveySummary=x;
	}
	void display()const
	{
		cout<<"Survey Summary:"<<surveySummary<<endl;
		Student::display();
	}
};
int main()
{
	Person*ptr;
	Student s('A',29,"Alisha",56);
	ptr=&s;
	ptr->display();
	
	Teacher t(65000,3500,"Iram",34);
	ptr=&t;
	ptr->display();
	
	BS_student b("AI Project","Sara",12,'B',90);
	ptr=&b;
	ptr->display();
	
	MS_student m("Survey on Robotics","Iqra",78,'A',88);
	ptr=&m;
	ptr->display();
	
	return 0;
}
