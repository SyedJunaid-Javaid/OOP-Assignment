#include<iostream>
using namespace std;
class Calculator{
	protected:
		int num1,num2,total;
		public:
			void setNum1(int n){
				num1=n;	}
			int getNum1(){
				return num1;		}
				void setNum2(int m){
				num2=m;		}
			int getNum2(){
				return num2;		}
			~Calculator(){
				cout<<"Calculator cobj destroyed"<<endl;		}
			Calculator(){
				num1=0;
				num2=0;	}
			Calculator(int w, int q){
				num1=w;
				num2=q;		}
		virtual	void display(){
			cout<<"num1:"<<num1<<endl;
			cout<<"num2:"<<num2<<endl;
			cout<<"sum="<<total<<endl;	}
			int add(){
				total=num1+num2;
				return total;	}
};
class SC_calculater:public Calculator{
	private:
		int num3,num4;
		public:
			void setNum3(int o){
				num3=o;	}
			int getNum3(){
				return num3;	}
				void setNum4(int p){
				num4=p;	}
			int getNum4(){
				return num4;	}
			~SC_calculater(){
				cout<<"SC_calculater cobj destroyed"<<endl;	}
			SC_calculater(int e, int r,int t, int y):Calculator(t,y){
				num3=e;
				num4=r;	}
			void display(){
				Calculator::display();
				cout<<"square of num3=:"<<num3<<endl;
				cout<<"square of num4=:"<<num4<<endl;	
				num3=num3*num3;
				num4=num4*num4;
				}
};
int main(){
	Calculator* ptr;
	SC_calculater s1(2,3,4,5);
	ptr=&s1;
	ptr->add();
	ptr->display();
	return 0;
}
